import android, time

droid = android.Android()
droid.aHelloFunction("hello message")
message = droid.getCustomMessage().result

while 1:
	droid.makeToast(message)
	time.sleep(5)
	
