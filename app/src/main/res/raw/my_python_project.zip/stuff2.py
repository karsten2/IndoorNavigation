def myOtherFunction():
	return 'myOtherFunction'
