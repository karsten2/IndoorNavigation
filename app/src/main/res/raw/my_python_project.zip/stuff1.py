def myFunction():
	return 'myFunction'
